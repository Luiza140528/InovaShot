# Pipeline de vídeo (FFmpeg)

## Corte de silêncio — histórico importante
Bug já resolvido em 28/07/2026: `removeSilence()` em `backend/src/server.js`
só capturava log do `ffmpeg silencedetect` no bloco `catch`, mas o comando
retorna exit code 0 mesmo detectando silêncio — então o catch nunca disparava
e o clipe original saía sem corte. Fix: passou a capturar stdout/stderr no
caminho de sucesso do `execAsync` também. Validado com vídeo sintético de 10s
(silêncio em 2-4s e 6-8s): antes saía 10s, depois saiu 6.03s.

**Lição**: ao mexer em qualquer função que dependa de `execAsync`/`exec` com
ferramentas de linha de comando, sempre verificar o exit code real da
ferramenta antes de assumir que erro só aparece via exceção.

## Ao investigar bugs nesse pipeline
1. Reproduzir com um caso sintético pequeno e conhecido (não com vídeo real
   longo) antes de mexer em produção.
2. Checar `backend/src/server.js` primeiro — é onde a lógica de silêncio e
   geração de clipe vive hoje.
3. Nunca reportar como "resolvido" sem teste ao vivo confirmando o resultado
   esperado.

## Pendências não resolvidas ainda
- Auto-otimização/orquestração de jobs assíncronos (download, transcrição,
  scoring) ainda roda via cron simples no PM2 — considerar dividir em 3
  gatilhos separados (ingestão / processamento / manutenção-distribuição)
  quando o volume justificar.
