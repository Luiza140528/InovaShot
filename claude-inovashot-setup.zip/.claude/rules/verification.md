# Verificação — nunca afirmar sem evidência

## Regra principal
Nunca reportar um bug como resolvido, uma feature como funcionando, ou uma
integração como validada só porque a mudança "parece certa" ou está
documentada como implementada. Só reportar como resolvido depois de rodar
um teste real e colar a evidência (log, output de comando, ou print).

Isso já aconteceu antes no InovaShot: o corte de silêncio (FFmpeg) ficou
documentado como implementado por um tempo sem confirmação real, e o bug do
Trends no Módulo Político também precisou de teste ao vivo pra confirmar.

## Como aplicar em qualquer sessão
1. Depois de qualquer correção ou nova feature, definir um jeito de checar
   pass/fail: rodar o servidor e testar o endpoint, gerar um caso sintético
   pequeno (ex: vídeo de 10s com silêncio conhecido), checar logs do PM2, etc.
2. Colar a evidência da checagem na conversa antes de dizer "resolvido".
3. Se não é possível verificar agora (ex: depende de token que expira, ou de
   ambiente que só existe em produção), dizer isso explicitamente — não
   assumir que funciona.

## Revisão antes de considerar algo pronto
Para mudanças maiores (nova integração, mudança em pipeline crítico como
FFmpeg ou Threads), pedir uma segunda checagem numa sessão/contexto separado
antes de encerrar:

> "Revisa esse diff/mudança contra o que era esperado. Aponta só o que afeta
> corretude ou os requisitos — não preferência de estilo."

Isso evita o viés de quem acabou de escrever o código validar o próprio
trabalho.

## Antes de features maiores: explorar → planejar → codar
Para mudanças que tocam múltiplos arquivos ou área desconhecida do sistema,
pedir pra investigar e montar um plano antes de implementar direto. Pra
correções pequenas e escopo claro (typo, log, variável), pode pedir direto
sem esse passo extra.
