# Integração Threads

Publicação automática em produção desde 21/07/2026: clipe com nota de
viralidade ≥7 gera legenda via Claude Haiku e publica sozinho em
@inovashot.cortes via graph.threads.net (`POST me/threads` → `creation_id`
→ `POST me/threads_publish`). Lógica em `threads-publisher.js`, integrado ao
`server.js`.

IDs de referência:
- Meta App ID: 1347752133848054
- Threads App ID: 1868212397919801
- Facebook Page ID: 1224411967402653

Requisitos:
- Bucket `clips` do Supabase precisa estar público.
- `THREADS_ACCESS_TOKEN` (~60 dias) vive só no `.env` de produção do
  DigitalOcean — nunca no repo, nunca colado em chat.

## Pendência de segurança
Chave secreta do app e o token já apareceram em texto claro num chat antes.
Rotacionar ambos no painel Meta for Developers assim que possível. Ver
`rules/security.md` para o hook que bloqueia isso no futuro.

## Ao trabalhar nessa integração
- Confirmar publicação real rodando no servidor:
  `pm2 logs inovashot --lines 50 --nostream | grep -i threads`
- Token expira em ~60 dias — se publicação parar de funcionar, checar
  validade do token antes de investigar código.
