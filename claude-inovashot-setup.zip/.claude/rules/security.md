# Segurança

- Nenhum token, chave de API, ou segredo deve ser colado em texto claro no
  chat ou commitado no repo. Sempre `.env` de produção, nunca versionado.
- Hook de commit ativo (`check-secrets.sh`, ver `settings.json`) bloqueia
  automaticamente qualquer commit com padrão suspeito de token antes que
  aconteça — mas isso é uma rede de segurança, não desculpa pra colar
  segredo em qualquer lugar.
- Pendência conhecida: token e chave secreta do app Threads vazaram em chat
  antes do hook existir — rotacionar no painel Meta for Developers.
- Ao adicionar uma nova integração externa (nova API, novo serviço), sempre
  perguntar: "esse segredo vai pro .env de produção ou vai vazar em algum
  commit/log/chat?" antes de implementar.
