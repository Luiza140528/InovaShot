# InovaShot — contexto principal

SaaS de clipping de vídeo com IA para criadores brasileiros. Backend Node.js
no DigitalOcean (Ubuntu, PM2, Nginx), frontend em branch `main-/-frontend`,
banco Supabase. Repo: Luiza140528/InovaShot.

Pipeline: download YouTube → transcrição Whisper+Claude → geração de clipes
→ corte de silêncio (FFmpeg) → scoring de viralidade → hook A/B → legenda
(Claude Haiku) → publicação automática no Threads (nota ≥7).

Regras gerais:
- Sempre entregar arquivo completo, nunca trecho parcial de código.
- Nunca commitar segredo/token em texto claro — ver `rules/security.md`.
- Antes de reportar um bug como resolvido, confirmar com teste ao vivo,
  não só porque está documentado como implementado.
- Detalhes específicos de cada área do sistema estão em `rules/`, carregados
  só quando relevantes — não duplicar aqui.
